<?php
// Facebook Conversions API (CAPI) Handler
// Handles "PageView" event server-side

$access_token = 'EAATDZBBlSuA0BQnixGEHq4qZBS5SZA9kw1tXOPw8ZCdxZALVH6765eNGIjyOmev4Fr8vUF0LmzZCrCzV3lto8ZBjOtr44DbjCxLdpoBbCg7vj2uefuBZAz73Xlb1VghjdWZB0QOp9ZAMUfB5gSQpzqv8ZC4RrzVU0s0dqGlpIJUkCUD2MF5LqKtOjZCUynNnprQ8JQZDZD';
$pixel_id = '2056520708244599';

// Get User Data
$client_ip = $_SERVER['REMOTE_ADDR'];
$client_user_agent = $_SERVER['HTTP_USER_AGENT'];
$fbp = isset($_COOKIE['_fbp']) ? $_COOKIE['_fbp'] : null;
$fbc = isset($_COOKIE['_fbc']) ? $_COOKIE['_fbc'] : null;

// Event Data
$data = [
    'data' => [
        [
            'event_name' => 'PageView',
            'event_time' => time(),
            'event_source_url' => (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]",
            'action_source' => 'website',
            'user_data' => [
                'client_ip_address' => $client_ip,
                'client_user_agent' => $client_user_agent,
                'fbp' => $fbp,
                'fbc' => $fbc
            ]
        ]
    ]
];

// Send to Facebook
$url = "https://graph.facebook.com/v19.0/{$pixel_id}/events?access_token={$access_token}";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

// Return generic success (silent)
header('Content-Type: application/json');
echo json_encode(['status' => 'sent', 'fb_response' => json_decode($response)]);
?>
